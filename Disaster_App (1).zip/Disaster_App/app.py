from flask import Flask, render_template, request
import pickle
import numpy as np


model = pickle.load(open('xgboost_model.pkl', 'rb'))
le = pickle.load(open('le.pkl', 'rb'))
te = pickle.load(open('target_encoder.pkl','rb'))

app = Flask(__name__)

# Define the route for the index page
@app.route('/')
def index():
    return render_template('index.html')

# Define the route for the prediction
@app.route('/predict', methods=['POST'])
def predict():
    # Retrieve the input data from the form
    input_country = request.form.get('input_country')
    input_year = int(request.form.get('input_year'))
    input_season = request.form.get('input_season')

    # Transform the input data using the label encoder
    try:
        input_country_encoded = le.transform([input_country])[0]
    except ValueError:
        # Handle unseen label
        input_country_encoded = -1
    try:
        input_season_encoded = le.transform([input_season])[0]
    except ValueError:
        # Handle unseen season label
        input_season_encoded = -1 

    # Perform the prediction using your XGBoost classifier model
    input_data = np.array([[input_country_encoded, input_year, input_season_encoded]])
    try:
        prediction = model.predict(input_data)
        predicted_disaster_type = te.inverse_transform(prediction)[0]
    except ValueError as e:
        predicted_disaster_type = "Invalid"

    # Render the prediction result page
    return render_template('prediction.html', input_country=input_country, input_year=input_year, input_season=input_season, prediction=predicted_disaster_type)


# Run the Flask application
if __name__ == '__main__':
    app.run(debug=True)

