from flask import Flask, render_template, request, jsonify
import pickle
import numpy as np

app = Flask(__name__)

model = pickle.load(open('xgboost_model.pkl', 'rb'))
le = pickle.load(open('le.pkl', 'rb'))
te = pickle.load(open('target_encoder.pkl','rb'))

# Define the route for the index page
@app.route('/')
def index():
    return render_template('index.html')

# Define the route for the prediction
@app.route('/predict', methods=['POST'])
def predict():
    # Retrieve the input data from the form
    input_country = request.form.get('input_country')
    input_year = int(request.form.get('input_year'))
    input_season = request.form.get('input_season')

    # Perform label encoding
    country_encoded = le.transform([input_country])[0]
    season_encoded = le.transform([input_season])[0]

    # Create feature vector
    features = [country_encoded, input_year, season_encoded]

    # Encode the features using target encoder
    encoded_features = te.transform([features])

    # Make prediction using the trained model
    prediction = model.predict(encoded_features)

    # Decode the predicted target value
    decoded_prediction = te.inverse_transform(prediction)

    # Render the prediction result page
    return jsonify('prediction.html', input_country=input_country, input_year=input_year, input_season=input_season, decoded_prediction=decoded_prediction)


# Run the Flask application
if __name__ == '__main__':
    app.run(debug=True)